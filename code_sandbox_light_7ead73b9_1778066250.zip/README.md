# Senaka Oshitaru 合同会社 - Corporate Website

> **「作業」をAIへ。「志」を未来へ。**
> AIネイティブな組織変革で、人間が生き生きと輝く創造的経営を。

---

## 📋 プロジェクト概要

**Senaka Oshitaru合同会社** のコーポレートサイトです。
AI導入支援・キャリアコーチング・SNSマーケティング支援を通じて、AIネイティブな組織への変革を伴走する、AI時代の経営パートナーとしてのブランドサイトを構築しました。

### コンセプト
- **カラー**: ディープネイビー (`#020714`) を基調に、テックブルー (`#4f8cff`) × バイオレット (`#7b5bff`) × マゼンタ (`#ff5bd1`) のグラデーションをアクセント
- **タイポグラフィ**:
  - 英語見出し: Inter (sans-serif)
  - 日本語見出し: Noto Serif JP (明朝体で「志」「作業」などのキーワードに重みを与える)
  - 本文: Noto Sans JP
- **世界観**: 「先進的なAI × 人間の志」が共存する未来感

---

## ✅ 実装済みのセクション (上から順)

| # | セクションID | 内容 |
|---|------------|------|
| 1 | `#top` | **ヒーロー**: 「『作業』をAIへ。『志』を未来へ。」キャッチコピー、光の流線背景＋Canvasパーティクル、VIEW SERVICE導線 |
| 2 | `#vision` | **OUR CONCEPT**: 粒子地球儀ビジュアル (元サイズ580pxに復元) + AI/PEOPLE/WILL のキーワードラベル |
| 3 | `#service` | **事業内容3つ**: AI研修 / キャリアコーチング / SNSマーケ (3カラムカード, ホバー演出) |
| 4 | `#message` | **代表挨拶**: 陸野嘉義 (Yoshigi Takano) 代表取締役社長のメッセージ全文＋ポートレート (背景はディープネイビーに調整済) |
| 5 | `#company` | **会社概要テーブル**: 社名・代表者・所在地・資本金・事業内容 |
| 6 | `#contact` | **CONTACT CTA**: 大型グラデーションボタン (mailto: 設定済) |
| 7 | footer | **フッター**: ロゴ・タグライン・SNS・3カラムリンク・CONTACTカード・コピーライト |

### 主なインタラクション
- スクロール連動でヘッダーのブラー&縮小
- Intersection Observerによるサービスカードの時差レビール
- Canvasによる粒子ネットワークアニメーション
- 地球儀の自動回転＋グロウパルス
- ボタンの左→右グラデーションスライドホバー
- スムーススクロール / ナビ現在地ハイライト
- モバイルドロワーメニュー（ハンバーガー）
- レスポンシブ対応 (1100px / 900px / 720px)

### アクセシビリティ
- セマンティックHTML (`<header>` `<main>` `<section>` `<article>` `<footer>` `<dl>` 等)
- `aria-label` / `aria-expanded` / `aria-hidden` 属性
- 明朝体と装飾を活用しつつ、本文は読みやすいゴシック体で確保

---

## 🌐 アンカーパス一覧 (表示順)

| パス | 内容 |
|------|------|
| `index.html` | トップページ (シングルページ構成) |
| `#top` | ヒーローセクション |
| `#vision` | OUR CONCEPT (私たちの考え) |
| `#service` | OUR SERVICE (事業内容3サービス) |
| `#message` | MESSAGE (代表挨拶) |
| `#company` | COMPANY (会社概要) |
| `#contact` | CONTACT (お問い合わせCTA) |

---

## 📁 ファイル構成

```
.
├── index.html                  # メインページ (全セクション)
├── css/
│   └── style.css               # ダークテーマ + 全セクションスタイル
├── js/
│   └── main.js                 # スクロール / メニュー / Canvasパーティクル
├── images/
│   ├── hero-light.jpg          # ヒーロー背景 (光の流線)
│   ├── service-training.jpg    # ① AI & Business Skill Training
│   ├── service-coaching.jpg    # ② Corporate Career Coaching
│   ├── service-sns.jpg         # ③ SNS Marketing Support
│   ├── ceo-portrait.jpg        # 代表取締役 陸野 嘉義 ポートレート
│   └── vision-earth.jpg        # 粒子地球儀ビジュアル
└── README.md
```

---

## 🛠 使用技術 / ライブラリ

- **HTML5** (セマンティックタグ、`<dl>`によるテーブル表現)
- **CSS3** (Custom Properties / Grid / Flexbox / `clamp()` / `aspect-ratio` / `backdrop-filter` / グラデーションテキスト)
- **Vanilla JavaScript** (Intersection Observer / Canvas API / requestAnimationFrame)
- **Google Fonts** — Inter / Noto Sans JP / **Noto Serif JP** (新規追加)
- **Font Awesome 6** (アイコン)
- 外部API・サーバーサイド機能は使用していません(完全静的)

---

## 📊 会社概要データ (HTMLに記述)

| 項目 | 内容 |
|------|------|
| 社名 | Senaka Oshitaru合同会社 |
| 代表者 | 代表取締役社長 陸野 嘉義 (Yoshigi Takano) |
| 所在地 | 〒252-0011 神奈川県座間市相武台2-13-10 |
| 資本金 | 1,000,000円 |
| 事業内容 | AI導入支援・研修事業 / 法人向けキャリアコーチング / SNSマーケティング支援 |

---

## 📊 データモデル / ストレージ

このサイトは現時点で完全静的で、**RESTful Table API は未使用** です。
将来的に動的化する場合の推奨テーブル設計:

| テーブル名 | 用途 | フィールド例 |
|-----------|------|--------------|
| `inquiries` | 問い合わせ受付 | `id` `name` `email` `company` `category` `message` (rich_text) `created_at` |
| `news` | お知らせ | `id` `date` (datetime) `category` `title` `body` (rich_text) |
| `case_studies` | 導入事例 | `id` `client_name` `industry` `service_type` `summary` `result` (rich_text) |

---

## 🚧 未実装の機能 / 今後の推奨開発ステップ

### 未実装
- お問い合わせフォーム本体 (現在は `mailto:` リンクのみ)
- 各サービスの詳細ページ (`/service/training.html` など)
- 導入事例 / お客様の声ページ
- ニュース・ブログ機能
- プライバシーポリシー / 特定商取引法に基づく表記の本文ページ
- favicon / OGP / Twitter Cardメタ情報
- Google Analytics 等の計測タグ

### 推奨される次のステップ
1. **CONTACTフォーム** を Table API (`inquiries` テーブル) で実装
2. **代表者の写真** を message セクションに追加（プロフィール感の強化）
3. **導入事例** ページ・コンテンツの追加 (信頼感の向上)
4. **ブログ／コラム** で「AIネイティブな組織」「キャリア」などの情報発信
5. SEO 強化 (構造化データ、OGP、`sitemap.xml`、`robots.txt`)
6. 画像のWebP化・遅延読み込み (Lighthouse スコア改善)
7. WCAG 2.1 AA レベルのアクセシビリティ監査

---

## 🚀 デプロイ

サイトを公開するには、画面上部の **Publish タブ** からワンクリックでデプロイできます。
公開後のURLはPublishタブで確認できます。

---

© 2026 Senaka Oshitaru LLC. All Rights Reserved.
