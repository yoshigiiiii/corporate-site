/* ============================================
   XTech Corporate Site - Main JavaScript
   ============================================ */

(function () {
    'use strict';

    // ===== Header scroll state =====
    const header = document.getElementById('global-header');
    const onScroll = () => {
        if (window.scrollY > 30) {
            header.classList.add('is-scrolled');
        } else {
            header.classList.remove('is-scrolled');
        }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    // ===== Mobile menu toggle =====
    const menuToggle = document.getElementById('menu-toggle');
    const drawer = document.getElementById('mobile-drawer');
    if (menuToggle && drawer) {
        menuToggle.addEventListener('click', () => {
            const isOpen = drawer.classList.toggle('is-open');
            menuToggle.classList.toggle('is-open', isOpen);
            menuToggle.setAttribute('aria-expanded', String(isOpen));
            drawer.setAttribute('aria-hidden', String(!isOpen));
            document.body.style.overflow = isOpen ? 'hidden' : '';
        });
        drawer.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                drawer.classList.remove('is-open');
                menuToggle.classList.remove('is-open');
                menuToggle.setAttribute('aria-expanded', 'false');
                drawer.setAttribute('aria-hidden', 'true');
                document.body.style.overflow = '';
            });
        });
    }

    // ===== Active nav link by section =====
    const navLinks = document.querySelectorAll('.primary-nav .nav-link');
    const sections = ['top', 'vision', 'service', 'message', 'company', 'contact']
        .map(id => document.getElementById(id))
        .filter(Boolean);

    const updateActiveNav = () => {
        const scrollPos = window.scrollY + window.innerHeight * 0.35;
        let currentId = 'top';
        sections.forEach(sec => {
            if (sec.offsetTop <= scrollPos) {
                currentId = sec.id;
            }
        });
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            link.classList.toggle('is-active', href === '#' + currentId);
        });
    };
    window.addEventListener('scroll', updateActiveNav, { passive: true });

    // ===== Reveal on scroll =====
    const reveals = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window) {
        const io = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const delay = entry.target.dataset.delay || 0;
                    setTimeout(() => {
                        entry.target.classList.add('is-visible');
                    }, Number(delay));
                    io.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 });
        reveals.forEach(el => io.observe(el));
    } else {
        reveals.forEach(el => el.classList.add('is-visible'));
    }

    // ===== Hero particle canvas =====
    const canvas = document.getElementById('particle-canvas');
    if (canvas && canvas.getContext) {
        const ctx = canvas.getContext('2d');
        let w = 0, h = 0, dpr = Math.min(window.devicePixelRatio || 1, 2);
        let particles = [];

        const resize = () => {
            const rect = canvas.getBoundingClientRect();
            w = rect.width;
            h = rect.height;
            canvas.width = w * dpr;
            canvas.height = h * dpr;
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        };

        const createParticles = () => {
            const count = Math.min(80, Math.floor((w * h) / 18000));
            particles = [];
            for (let i = 0; i < count; i++) {
                particles.push({
                    x: Math.random() * w,
                    y: Math.random() * h,
                    r: Math.random() * 1.6 + 0.4,
                    vx: (Math.random() - 0.5) * 0.25,
                    vy: (Math.random() - 0.5) * 0.25,
                    a: Math.random() * 0.6 + 0.2,
                    hue: Math.random() < 0.5 ? '#4f8cff' : (Math.random() < 0.5 ? '#00d2ff' : '#7b5bff')
                });
            }
        };

        const draw = () => {
            ctx.clearRect(0, 0, w, h);
            // Draw connections
            for (let i = 0; i < particles.length; i++) {
                const p = particles[i];
                p.x += p.vx;
                p.y += p.vy;
                if (p.x < 0 || p.x > w) p.vx *= -1;
                if (p.y < 0 || p.y > h) p.vy *= -1;

                for (let j = i + 1; j < particles.length; j++) {
                    const q = particles[j];
                    const dx = p.x - q.x;
                    const dy = p.y - q.y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    if (dist < 130) {
                        ctx.strokeStyle = `rgba(79, 140, 255, ${(1 - dist / 130) * 0.18})`;
                        ctx.lineWidth = 0.6;
                        ctx.beginPath();
                        ctx.moveTo(p.x, p.y);
                        ctx.lineTo(q.x, q.y);
                        ctx.stroke();
                    }
                }
            }
            // Draw particles
            particles.forEach(p => {
                ctx.beginPath();
                ctx.fillStyle = p.hue;
                ctx.globalAlpha = p.a;
                ctx.shadowColor = p.hue;
                ctx.shadowBlur = 8;
                ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                ctx.fill();
            });
            ctx.globalAlpha = 1;
            ctx.shadowBlur = 0;
            requestAnimationFrame(draw);
        };

        const init = () => {
            resize();
            createParticles();
            draw();
        };

        window.addEventListener('resize', () => {
            resize();
            createParticles();
        });
        init();
    }

    // ===== Smooth scroll for in-page anchors =====
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', (e) => {
            const targetId = anchor.getAttribute('href');
            if (targetId.length <= 1) return;
            const target = document.querySelector(targetId);
            if (target) {
                e.preventDefault();
                const headerOffset = 70;
                const top = target.getBoundingClientRect().top + window.scrollY - headerOffset;
                window.scrollTo({ top, behavior: 'smooth' });
            }
        });
    });

    // ===== Play movie button (placeholder) =====
    const playBtn = document.querySelector('.play-movie-btn');
    if (playBtn) {
        playBtn.addEventListener('click', () => {
            // Placeholder: ムービーモーダルなどを後日実装可能
            console.log('Play movie clicked');
        });
    }

    // ===== Hero pagination tick (decorative) =====
    const dots = document.querySelectorAll('.hero-pagination li');
    if (dots.length) {
        let idx = 0;
        setInterval(() => {
            dots.forEach(d => d.classList.remove('is-active'));
            idx = (idx + 1) % dots.length;
            dots[idx].classList.add('is-active');
        }, 4500);
    }

})();
